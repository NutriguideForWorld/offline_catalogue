from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import unquote, urlparse, quote
import json
import mimetypes

BASE_DIR = Path(__file__).resolve().parent
SITE_DIR = BASE_DIR / "site"
CATALOGUE_DIR = BASE_DIR / "Product_catalogue"

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".gif"}


def safe_path(root: Path, relative_path: str):
    """Return a safe file path inside root, or None if traversal is attempted."""
    root = root.resolve()
    target = (root / relative_path).resolve()

    if target == root or root in target.parents:
        return target

    return None


def media_url(file_path: Path):
    relative_path = file_path.relative_to(CATALOGUE_DIR).as_posix()
    return "/media/" + quote(relative_path)


def load_product(product_folder: Path):
    metadata_file = product_folder / "product.json"
    product_data = {}

    if metadata_file.exists():
        try:
            product_data = json.loads(metadata_file.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            print(f"Warning: Invalid JSON in {metadata_file}")

    configured_images = product_data.get("images", [])
    images = []

    if isinstance(configured_images, list):
        for image_name in configured_images:
            image_path = product_folder / image_name
            if image_path.exists() and image_path.suffix.lower() in IMAGE_EXTENSIONS:
                images.append(media_url(image_path))

    if not images:
        images = [
            media_url(image_path)
            for image_path in sorted(product_folder.iterdir())
            if image_path.is_file()
            and image_path.suffix.lower() in IMAGE_EXTENSIONS
        ]

    metadata = product_data.get("metadata", {})

    if not isinstance(metadata, dict):
        metadata = {}

    # Add top-level fields other than name, images, and metadata.
    for key, value in product_data.items():
        if key not in {"name", "images", "metadata"}:
            metadata[key] = value

    return {
        "id": product_folder.name,
        "name": product_data.get("name", product_folder.name.replace("_", " ")),
        "images": images,
        "metadata": metadata,
    }


def build_catalogue():
    categories = []

    if not CATALOGUE_DIR.exists():
        return {"categories": categories}

    for category_folder in sorted(CATALOGUE_DIR.iterdir()):
        if not category_folder.is_dir() or category_folder.name.startswith("."):
            continue

        products = []

        for product_folder in sorted(category_folder.iterdir()):
            if not product_folder.is_dir() or product_folder.name.startswith("."):
                continue

            product = load_product(product_folder)

            # Include folders even when an image is missing,
            # but they will show an empty image area.
            products.append(product)

        categories.append({
            "id": category_folder.name,
            "name": category_folder.name.replace("_", " "),
            "products": products
        })

    return {"categories": categories}


class CatalogueHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        parsed_url = urlparse(self.path)
        path = unquote(parsed_url.path)

        if path == "/api/catalogue":
            catalogue = build_catalogue()
            response = json.dumps(catalogue, ensure_ascii=False).encode("utf-8")

            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(response)))
            self.end_headers()
            self.wfile.write(response)
            return

        if path.startswith("/media/"):
            relative_path = path.removeprefix("/media/")
            file_path = safe_path(CATALOGUE_DIR, relative_path)

            if not file_path or not file_path.is_file():
                self.send_error(404, "Media file not found")
                return

            self.send_file(file_path)
            return

        if path == "/":
            path = "/index.html"

        file_path = safe_path(SITE_DIR, path.lstrip("/"))

        if not file_path or not file_path.is_file():
            self.send_error(404, "File not found")
            return

        self.send_file(file_path)

    def send_file(self, file_path: Path):
        content_type, _ = mimetypes.guess_type(str(file_path))
        content_type = content_type or "application/octet-stream"

        try:
            file_data = file_path.read_bytes()

            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(file_data)))
            self.end_headers()
            self.wfile.write(file_data)
        except OSError:
            self.send_error(500, "Could not read file")

    def log_message(self, format, *args):
        print(f"[Catalogue] {args[0]}")


if __name__ == "__main__":
    server_address = ("127.0.0.1", 8000)

    print("Offline catalogue running at:")
    print("http://127.0.0.1:8000")

    print("\nPress Ctrl+C to stop the server.")

    HTTPServer(server_address, CatalogueHandler).serve_forever()
