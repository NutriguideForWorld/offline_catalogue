const state = {
  categories: [],
  categoryIndex: 0,
  productIndex: 0
};

const elements = {
  categoryList: document.getElementById("categoryList"),
  categoryTitle: document.getElementById("categoryTitle"),
  productContent: document.getElementById("productContent"),
  emptyState: document.getElementById("emptyState"),
  productImage: document.getElementById("productImage"),
  noImageMessage: document.getElementById("noImageMessage"),
  productName: document.getElementById("productName"),
  productPosition: document.getElementById("productPosition"),
  metadataList: document.getElementById("metadataList"),
  previousButton: document.getElementById("previousButton"),
  nextButton: document.getElementById("nextButton"),
  thumbnailBar: document.getElementById("thumbnailBar"),
  thumbnailCount: document.getElementById("thumbnailCount")
};

function getCurrentCategory() {
  return state.categories[state.categoryIndex];
}

function getCurrentProduct() {
  const category = getCurrentCategory();
  return category?.products[state.productIndex];
}

function formatValue(value) {
  if (value === null || value === undefined || value === "") {
    return "—";
  }

  if (Array.isArray(value)) {
    return value.join(", ");
  }

  if (typeof value === "object") {
    return JSON.stringify(value, null, 2);
  }

  return String(value);
}

function renderCategories() {
  elements.categoryList.replaceChildren();

  state.categories.forEach((category, index) => {
    const button = document.createElement("button");

    button.type = "button";
    button.className = "category-button";
    button.textContent = category.name;

    if (index === state.categoryIndex) {
      button.classList.add("active");
    }

    button.addEventListener("click", () => {
      state.categoryIndex = index;
      state.productIndex = 0;
      renderCatalogue();
    });

    elements.categoryList.appendChild(button);
  });
}

function renderMetadata(metadata) {
  elements.metadataList.replaceChildren();

  const entries = Object.entries(metadata || {});

  if (entries.length === 0) {
    const row = document.createElement("div");
    const label = document.createElement("dt");
    const value = document.createElement("dd");

    label.textContent = "Information";
    value.textContent = "No product metadata available.";

    row.append(label, value);
    elements.metadataList.appendChild(row);
    return;
  }

  entries.forEach(([key, value]) => {
    const row = document.createElement("div");
    const label = document.createElement("dt");
    const content = document.createElement("dd");

    label.textContent = key;
    content.textContent = formatValue(value);

    row.append(label, content);
    elements.metadataList.appendChild(row);
  });
}

function renderThumbnails(category) {
  elements.thumbnailBar.replaceChildren();
  elements.thumbnailCount.textContent = `${category.products.length} product${category.products.length === 1 ? "" : "s"}`;

  category.products.forEach((product, index) => {
    const button = document.createElement("button");
    const imageContainer = document.createElement("span");
    const name = document.createElement("span");

    button.type = "button";
    button.className = "product-thumbnail";

    if (index === state.productIndex) {
      button.classList.add("active");
    }

    imageContainer.className = "thumbnail-image";
    name.className = "thumbnail-name";
    name.textContent = product.name;

    if (product.images?.length) {
      const image = document.createElement("img");
      image.src = product.images[0];
      image.alt = product.name;
      image.loading = "lazy";
      imageContainer.appendChild(image);
    } else {
      const noImage = document.createElement("span");
      noImage.textContent = "No image";
      imageContainer.appendChild(noImage);
    }

    button.append(imageContainer, name);

    button.addEventListener("click", () => {
      state.productIndex = index;
      renderCatalogue();

      window.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    });

    elements.thumbnailBar.appendChild(button);
  });
}

function renderProduct() {
  const category = getCurrentCategory();
  const product = getCurrentProduct();

  if (!category || !product) {
    elements.productContent.hidden = true;
    elements.emptyState.hidden = false;
    elements.categoryTitle.textContent = "No products available";
    return;
  }

  elements.productContent.hidden = false;
  elements.emptyState.hidden = true;

  elements.categoryTitle.textContent = category.name;
  elements.productName.textContent = product.name;
  elements.productPosition.textContent =
    `Product ${state.productIndex + 1} of ${category.products.length}`;

  const firstImage = product.images?.[0];

  if (firstImage) {
    elements.productImage.src = firstImage;
    elements.productImage.alt = product.name;
    elements.productImage.hidden = false;
    elements.noImageMessage.hidden = true;
  } else {
    elements.productImage.removeAttribute("src");
    elements.productImage.alt = "";
    elements.productImage.hidden = true;
    elements.noImageMessage.hidden = false;
  }

  renderMetadata(product.metadata);
  renderThumbnails(category);

  elements.previousButton.disabled = state.productIndex === 0;
  elements.nextButton.disabled =
    state.productIndex === category.products.length - 1;
}

function renderCatalogue() {
  renderCategories();
  renderProduct();
}

function moveProduct(direction) {
  const category = getCurrentCategory();
  const nextIndex = state.productIndex + direction;

  if (!category || nextIndex < 0 || nextIndex >= category.products.length) {
    return;
  }

  state.productIndex = nextIndex;
  renderCatalogue();

  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });
}

elements.previousButton.addEventListener("click", () => moveProduct(-1));
elements.nextButton.addEventListener("click", () => moveProduct(1));

async function loadCatalogue() {
  try {
    const response = await fetch("/api/catalogue");

    if (!response.ok) {
      throw new Error("Catalogue data could not be loaded.");
    }

    const data = await response.json();

    state.categories = (data.categories || []).filter(
      (category) => category.products?.length > 0
    );

    renderCatalogue();
  } catch (error) {
    elements.productContent.hidden = true;
    elements.emptyState.hidden = false;
    elements.emptyState.innerHTML = `
      <h2>Catalogue could not be loaded</h2>
      <p>Start the catalogue using <code>python server.py</code>.</p>
    `;

    elements.categoryTitle.textContent = "Catalogue unavailable";
    console.error(error);
  }
}

loadCatalogue();
